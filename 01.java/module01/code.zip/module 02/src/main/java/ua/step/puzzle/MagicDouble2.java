package ua.step.puzzle;

/**
 * Объясни результат
 */
public class MagicDouble2
{
    public static void main(String[] args)
    {
        double value = 0.9999999999999999;
        System.out.println(value);
        value = 1.9999999999999999;
        System.out.println(value);
    }
}
