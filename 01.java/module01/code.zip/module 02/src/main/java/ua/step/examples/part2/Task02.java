package ua.step.examples.part2;

/**
 * Переменные дробных типов
 * 
 */
public class Task02
{
    public static void main(String[] args)
    {
        System.out.println(2.00 - 1.10); 
    }
}