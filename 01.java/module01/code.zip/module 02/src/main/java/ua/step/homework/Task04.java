package ua.step.homework;
/*
* Шаблон для решения домашнеего задания 4
*/
/**
 * Написать программу, которая выведет на консоль «Hello world» не используя в
 * исходном коде пробельных символов.
 * 
 *
 */
public class Task04
{
    public static void main(String[] args)
    {
        System.out.println();
    }
}
