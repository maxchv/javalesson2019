package ua.step.examples.part1;

/**
 * 
 * Вывод в консоль несколькими командами в одну строку
 *
 */
public class Task01
{
    public static void main(String[] args) 
    {  
    	// выводи информацию в консоль, без перевода строки
        System.out.print("Hello world"); 
    	System.out.print('!');
        int i = 1; // объявление переменной и начальная инициализация в одной строке.
    	System.out.print(i);
    	//FIXME измени код так, чтобы цифра 1 вывелась в отдельной строчкой
    } 
}