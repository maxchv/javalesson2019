package org.itstep.homework.bookstore;

/*************************************************************************
 *  Интерфейс человека							 *
 ************************************************************************/
interface Person {
    String getName();
    Address getAddress();
}
